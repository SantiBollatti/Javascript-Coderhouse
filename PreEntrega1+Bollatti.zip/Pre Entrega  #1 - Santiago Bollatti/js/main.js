let selector = parseInt(prompt("Bienvenido, pulse '1' para la calculadora de promedios o '2' para las tablas de multiplicación"))

while (isNaN(selector) || selector < 1 || selector > 2) {
    selector = parseInt(prompt("Pulse '1' para la calculadora de promedios o '2' para las tablas de multiplicación"))
}

while (selector >= 1 && selector <=2) {

    if (selector == 1) {
        
        alert('Bienvenido a la calculadora de promedios')
        calcularPromedio(parseInt(prompt('Ingrese la cantidad de números')))
        let continuar = confirm('Desea seguir utilizando la calculadora?')
        while (continuar == true) {
            calcularPromedio(Number(prompt('Ingrese la cantidad de números')))
            continuar = confirm('Desea continuar usando la calculadora?')
            if (continuar == false) {
                break
            }
        }
    
    } else {
        
        alert('Bienvenido a las tablas de multiplicación')
        multiplicar(Number(prompt('Ingrese la tabla que desea mostrar')))
        let continuar = confirm('Desea seguir utilizando la calculadora?')
        while (continuar == true) {
            multiplicar(Number(prompt('Ingrese la tabla la que desea acceder')))
            continuar = confirm('Desea continuar usando la calculadora?')
            if (continuar == false) {
                break
            }
        }

    }    
    
    let continuar = confirm('Desea salir del sistema?')
    if (continuar == true) {
        break
    } else {
    selector = prompt("Pulse '1' para calculadora de promedios, '2' para tablas de multiplicacion o cualquier tecla para salir")
    }
}

alert('Hasta luego 👋')

// FUNCIONES
function calcularPromedio(cantNum) {
    while (isNaN(cantNum) || cantNum <= 0) {
        cantNum = parseInt(prompt('La cantidad introducida no es válida, por favor intente de nuevo'))
    }
    let sumaNum = 0
    for (let i = 1; i <= cantNum; i++) {
        let num = Number(prompt('Ingrese el número ' + i + ':'))
        if (isNaN(num) || num <= 0) {
            alert('Por favor, ingrese un número correcto')
            i--
        } else {
            sumaNum = sumaNum + num
        }
    }
    let promedio = sumaNum / cantNum
    alert('El promedio entre los numeros ingresados es ' + promedio)
}
function multiplicar(tabla) {
    while (isNaN(tabla) || tabla <= 0) {
        tabla = Number(prompt('Por favor, ingrese un numero correcto'))
    }
    for (let j = 1; j <= 10; j++) {
        let multiplicacion = tabla * j
        console.log(tabla + ' x ' + j + ' = ' + multiplicacion)
    }
}




